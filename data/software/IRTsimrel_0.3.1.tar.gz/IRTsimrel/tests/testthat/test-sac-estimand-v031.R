test_that("reliability at expected information is distinct from mean form reliability", {
  form_information <- c(1, 9)
  theta_var <- 1

  rho_expected_information <- .irtsimrel_information_reliability(
    mean(form_information),
    theta_var
  )
  mean_form_reliability <- mean(vapply(
    form_information,
    .irtsimrel_information_reliability,
    numeric(1),
    theta_var = theta_var
  ))

  expect_equal(rho_expected_information, 5 / 6, tolerance = 1e-12)
  expect_equal(mean_form_reliability, 0.7, tolerance = 1e-12)
  expect_equal(
    rho_expected_information - mean_form_reliability,
    2 / 15,
    tolerance = 1e-12
  )
})


test_that("information SAC stores and predicts its declared aggregation", {
  fit <- suppressWarnings(sac_calibrate(
    target_rho = 0.65,
    n_items = 10L,
    model = "rasch",
    reliability_metric = "info",
    resample_items = TRUE,
    seed = 919L,
    M_pre = 300L,
    M_per_iter = 80L,
    n_iter = 10L,
    burn_in = 5L,
    c_bounds = c(0.1, 5),
    preflight_controls = list(
      n_forms = 4L,
      M = 150L,
      split_check = FALSE,
      root_controls = list(min_grid = 65L, max_evals = 257L)
    ),
    evaluation_controls = list(n_forms = 6L, M = 180L)
  ))

  expected <- .irtsimrel_information_reliability(
    mean(fit$achieved_distribution$form_mean_information),
    fit$theta_var
  )

  expect_identical(fit$schema_version, 2L)
  expect_identical(
    fit$item_aggregation,
    "functional_of_mean_information"
  )
  expect_identical(
    fit$estimating_equation,
    "scaled_mean_information_residual"
  )
  expect_equal(fit$achieved_rho, expected, tolerance = 1e-12)
  expect_equal(
    fit$mean_form_reliability,
    mean(fit$achieved_distribution$form_reliability),
    tolerance = 1e-12
  )
  expect_gte(fit$achieved_rho, fit$mean_form_reliability)
  expect_equal(
    as.numeric(predict(fit, newdata = fit$c_star)),
    fit$achieved_rho,
    tolerance = 1e-12
  )
  expect_identical(
    fit$preflight$item_aggregation,
    "functional_of_mean_information"
  )
})


test_that("legacy mean-form aggregation remains explicit", {
  fit <- suppressWarnings(sac_calibrate(
    target_rho = 0.65,
    n_items = 10L,
    model = "rasch",
    reliability_metric = "info",
    resample_items = TRUE,
    item_aggregation = "mean_of_form_reliabilities",
    seed = 920L,
    M_pre = 250L,
    M_per_iter = 60L,
    n_iter = 8L,
    burn_in = 4L,
    c_bounds = c(0.1, 5),
    preflight_controls = list(
      n_forms = 4L,
      M = 120L,
      split_check = FALSE,
      root_controls = list(min_grid = 65L, max_evals = 257L)
    ),
    evaluation_controls = list(n_forms = 5L, M = 150L)
  ))

  expect_identical(fit$item_aggregation, "mean_of_form_reliabilities")
  expect_identical(
    fit$estimating_equation,
    "transformed_functional_residual"
  )
  expect_equal(
    fit$achieved_rho,
    mean(fit$achieved_distribution$form_reliability),
    tolerance = 1e-12
  )
})
