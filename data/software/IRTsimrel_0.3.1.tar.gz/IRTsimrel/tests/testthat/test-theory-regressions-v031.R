# =============================================================================
# Theory regression oracles (v0.3.1)
# =============================================================================
# These deterministic checks guard the counterexamples and exact coefficients
# used by the authoritative theory vignettes.  They deliberately use only
# elementary probability identities and numerical integration, independently
# of the package calibration routines.
# =============================================================================

.theory_logistic_information_kernel <- function(x) {
  stats::plogis(x) * stats::plogis(-x)
}

.theory_mixture_information <- function(scale) {
  weights <- c(0.9998, 0.0001, 0.0001)
  means <- c(3, 0, -100)
  component_sd <- 0.15

  component_values <- vapply(
    means,
    function(location) {
      stats::integrate(
        function(z) {
          scale^2 * .theory_logistic_information_kernel(
            scale * (location + component_sd * z)
          ) * stats::dnorm(z)
        },
        lower = -Inf,
        upper = Inf,
        rel.tol = 1e-11,
        abs.tol = 1e-13
      )$value
    },
    numeric(1)
  )

  sum(weights * component_values)
}

.theory_three_pl_coefficient <- function(guessing) {
  if (guessing == 0) {
    return(1)
  }
  1 - guessing / (1 - guessing) * log(1 / guessing)
}

test_that("CX-02: a smooth finite-variance population can have three target roots", {
  target <- 0.02
  weights <- c(0.9998, 0.0001, 0.0001)
  means <- c(3, 0, -100)
  component_sd <- 0.15
  latent_mean <- sum(weights * means)
  latent_variance <- sum(
    weights * (component_sd^2 + means^2)
  ) - latent_mean^2
  density_at_item <- sum(
    weights * stats::dnorm(0, mean = means, sd = component_sd)
  )
  brackets <- list(c(0.3, 0.5), c(1.5, 2), c(50, 100))
  endpoint_residuals <- vapply(
    unlist(brackets),
    function(scale) .theory_mixture_information(scale) - target,
    numeric(1)
  )

  expect_identical(sign(endpoint_residuals), c(-1, 1, 1, -1, -1, 1))
  expect_equal(latent_variance, 1.08418764, tolerance = 1e-10)
  expect_gt(density_at_item, 0)
  expect_equal(
    latent_variance * target / (1 + latent_variance * target),
    0.0212235466607,
    tolerance = 2e-12
  )

  roots <- vapply(
    brackets,
    function(bracket) {
      stats::uniroot(
        function(scale) .theory_mixture_information(scale) - target,
        interval = bracket,
        tol = 1e-10
      )$root
    },
    numeric(1)
  )

  expect_equal(
    roots,
    c(0.315071350141, 1.639339526494, 76.134626761430),
    tolerance = 2e-8
  )
})

test_that("CX-03: the normal one-item reciprocal-information tail is quadratic", {
  scales <- c(2, 4, 6, 8)
  exact_msem <- 2 * (1 + exp(scales^2 / 2)) / scales^2
  exact_reliability <- 1 / (1 + exact_msem)
  tail_equivalent <- scales^2 / 2 * exp(-scales^2 / 2)

  # Pointwise identity: 1 / {c^2 p(1-p)} =
  # {exp(-c theta) + 2 + exp(c theta)} / c^2.
  theta <- c(-3, -0.5, 0, 1.25, 4)
  scale <- 1.7
  probability <- stats::plogis(scale * theta)
  direct_inverse <- 1 / (scale^2 * probability * (1 - probability))
  identity_inverse <-
    (exp(-scale * theta) + 2 + exp(scale * theta)) / scale^2
  expect_equal(direct_inverse, identity_inverse, tolerance = 2e-12)

  expect_equal(exact_reliability[[4L]] / tail_equivalent[[4L]], 1,
               tolerance = 2e-12)
  expect_true(all(diff(log(exact_reliability) / scales) < 0))
  expect_gt(exact_msem[[4L]], 1e12)
  expect_lt(exact_reliability[[4L]], 1e-12)
})

test_that("CX-06: local overlap is necessary for the average-information limit", {
  scales <- c(4, 8, 16)
  desert_information <- scales *
    (stats::plogis(2 * scales) - stats::plogis(scales))
  tail_equivalent <- scales * exp(-scales)

  expect_equal(
    desert_information[[3L]] / tail_equivalent[[3L]],
    1,
    tolerance = 3e-7
  )
  expect_true(all(diff(desert_information) < 0))
  expect_lt(desert_information[[3L]], 2e-6)

  theta_variance <- 1 / 12
  reliability <- theta_variance * desert_information /
    (1 + theta_variance * desert_information)
  expect_true(all(diff(reliability) < 0))
  expect_lt(reliability[[3L]], 2e-7)
})

test_that("CX-11: reciprocal-tail divergence requires a density lower bound", {
  right_endpoints <- c(10, 20, 40, 80)
  scale <- 1
  discrimination <- 1
  difficulty <- 0
  lower_constant <- 2
  tail_index <- 2
  effective_discrimination <- scale * discrimination

  # If f(theta) >= d0 theta^(-(nu+1)), integrating the elementary
  # reciprocal-information lower bound over each [R, R+1] gives this log
  # lower bound.  Its linear term dominates the logarithmic term.
  log_unit_interval_lower <-
    log(lower_constant) - 2 * log(effective_discrimination) +
    effective_discrimination * (right_endpoints - difficulty) -
    (tail_index + 1) * log(right_endpoints + 1)

  expect_true(all(diff(log_unit_interval_lower) > 0))
  expect_gt(log_unit_interval_lower[[4L]], 60)
  expect_gt(tail(diff(log_unit_interval_lower) /
                   diff(right_endpoints), 1L), 0.9)

  # Direction control: a normal density has a polynomial upper envelope on
  # [1, Inf), while its one-item MSEM at c = 1 is finite.  Such an upper bound
  # cannot be used as the divergent lower bound above.
  theta_star <- sqrt(tail_index + 1)
  upper_constant <- theta_star^(tail_index + 1) * stats::dnorm(theta_star)
  theta <- seq(1, 10, length.out = 1001)
  expect_true(all(
    stats::dnorm(theta) <=
      upper_constant * theta^(-(tail_index + 1)) + 1e-15
  ))
  expect_true(is.finite(2 * (1 + exp(1 / 2))))
})

test_that("CX-21: the 3PL local-overlap coefficient includes guessing", {
  guessing_values <- c(0, 0.2, 0.5, 0.9)
  closed_form <- vapply(
    guessing_values,
    .theory_three_pl_coefficient,
    numeric(1)
  )
  integral_form <- vapply(
    guessing_values,
    function(guessing) {
      stats::integrate(
        function(t) {
          (1 - guessing) * t /
            (guessing + (1 - guessing) * t)
        },
        lower = 0,
        upper = 1,
        rel.tol = 1e-12
      )$value
    },
    numeric(1)
  )

  expect_equal(closed_form, integral_form, tolerance = 2e-12)
  expect_equal(closed_form[[2L]], 0.597640521891, tolerance = 1e-12)
  expect_true(all(diff(closed_form) < 0))
  expect_lt(closed_form[[2L]], 1)
})

test_that("CX-05: the information SAC score has the declared mean-field root", {
  target_rho <- 0.7
  theta_variance <- 1.4
  target_information <- target_rho /
    (theta_variance * (1 - target_rho))
  score <- function(mean_information) {
    (1 - target_rho)^2 * (
      theta_variance * mean_information -
        target_rho / (1 - target_rho)
    )
  }

  expect_equal(score(target_information), 0, tolerance = 1e-15)
  expect_lt(score(0.9 * target_information), 0)
  expect_gt(score(1.1 * target_information), 0)

  implementation_scale <- theta_variance * (1 - target_rho)^2
  implementation_score <- implementation_scale *
    (1.1 * target_information - target_information)
  expect_equal(
    implementation_score,
    score(1.1 * target_information),
    tolerance = 5e-15
  )
})
